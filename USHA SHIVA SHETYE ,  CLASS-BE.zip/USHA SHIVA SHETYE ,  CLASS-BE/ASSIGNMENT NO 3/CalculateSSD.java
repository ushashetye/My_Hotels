package Demo;
import java.util.Scanner;
public class CalculateSSD {

	public static void main(String[] args) {
		int a[][]=new int[3][3];
		int b[][]=new int[3][3];
		int c[][]=new int[3][3];
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter first matrix data:");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		System.out.print("Enter second matrix data:");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				b[i][j]=sc.nextInt();
			}
		}
		System.out.print("first matrix:\n" );
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.print("\n");
		}
		System.out.print("Second matrix \n");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(b[i][j]+" ");
			}
			System.out.print("\n");
		}
		
		
		System.out.print("Sum = \n");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++) {
			
				c[i][j]=a[i][j]+b[i][j];
				System.out.print(c[i][j]+" ");
			}
			System.out.print("\n");
			}
			
			System.out.print("Sub = \n");
			for(int i=0;i<3;i++)
			{
				for(int j=0;j<3;j++)
				{
					c[i][j]=a[i][j]-b[i][j];
					System.out.print(c[i][j]+" ");
				}
				System.out.print("\n");
				}
				
				System.out.print("Div= \n");
				for(int i=0;i<3;i++)
				{
					for(int j=0;j<3;j++)
					{
						c[i][j]=a[i][j]/b[i][j];
						System.out.print(c[i][j]+" ");
					}
					System.out.print("\n");
					}
					
				
		

	}

}
