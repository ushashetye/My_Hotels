package Demo;
import java.util.Scanner;
public class SortingArrayElements {

	public static void main(String[] args) {
		int temp;
		int a[]=new int[6];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array elements:");
		for(int i=0;i<6;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<6;i++)
		{
			for(int j=i+1;j<6;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(int i=0;i<6;i++)
		{
			System.out.println(a[i]+" ");
		}

	}

}
