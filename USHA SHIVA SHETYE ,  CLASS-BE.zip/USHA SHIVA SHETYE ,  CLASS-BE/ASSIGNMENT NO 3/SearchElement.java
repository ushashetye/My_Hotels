package Demo;
import java.util.Scanner;
public class SearchElement {

	public static void main(String[] args) {
		int i,size=0,a;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		size=sc.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter the elements:");
		for(i=0; i<size; i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the element:");
		a=sc.nextInt();
		for(i=0; i<size; i++)
		{
			if(a==arr[i]) {
				System.out.println("Element found.");
			}
			else
			{
		        System.out.println("Element not found.");
			}
		}
		

	}

}
