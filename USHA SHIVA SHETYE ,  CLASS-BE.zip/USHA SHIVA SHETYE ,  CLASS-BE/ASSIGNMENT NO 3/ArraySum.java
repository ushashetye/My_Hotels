package Demo;
import java.util.Scanner;
public class ArraySum {

	public static void main(String[] args)
	{
		int temp=0, i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		int size=sc.nextInt();
		
		int arr[]=new int[size];
		System.out.println("Enter the elements:");
		for(i=0; i<size; i++)
		{
			arr[i]=sc.nextInt();
			temp=temp+arr[i];
		}
		int res=temp/size;
		System.out.println("Sum ="+temp);
		System.out.println("Average="+res);
		
	}
}
