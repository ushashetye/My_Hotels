package Demo;
import java.util.Scanner;
public class PrimeNoClass {

	public static void main(String[] args) {
		int i,j,n;
		String primeNumbers="";
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		n=sc.nextInt();		
	for(i=1; i<=n; i++)
	{
		int count=0;
		for(j=i; j>=1; j--)
		{
			if(i%j==0)
			{
				count=count+1;
			}
		}
		
		if (count==2)
		{
			primeNumbers=primeNumbers + i + " ";		}
		
	}
	//System.out.println("Prime numbers from 1 to 100 are:");
	System.out.println(primeNumbers);
	}

}
