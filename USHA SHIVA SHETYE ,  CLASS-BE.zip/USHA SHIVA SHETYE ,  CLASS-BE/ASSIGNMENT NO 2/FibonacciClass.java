package Demo;
import java.util.Scanner;
public class FibonacciClass {

	public static void main(String[] args) {
		int term,i,a=0,b=1,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		term=sc.nextInt();
		for(i=1; i<=term; i++)
		{
			System.out.println(a+ " ");
			c=a+b;
			a=b;
			b=c;
		}
	}

}
