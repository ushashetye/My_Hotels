package Demo;
import java.util.Scanner;
public class FactorialClass {

	
	public static void main(String[] args) {
	int i,fact=1,n;
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter number:");
	n=sc.nextInt();
	for(i=1; i<=n; i++)
	{
		fact=fact*i;
	}
	
	System.out.println("Factorial is:"+fact);

	}

}
