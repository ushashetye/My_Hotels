package Demo;

public class rectangleClass {
 int l,b,area,perimeter;
 
 void setValues() {
	 l=5;
	 b=8;
	 
	 area=l*b;
	 perimeter=2*l*b;
	 
 }
 public static void main(String[] args) {
	 rectangleClass obj=new rectangleClass();
	 
	 obj.setValues();
	 System.out.println("Area=" +obj.area);
	 System.out.println("Perimeter=" +obj.perimeter);
 }
}
