package Demo;

import java.math.*;
public class circleClass {
	int radius;
	float pi=3.14F, area, circumference;
	
	void setValues() {
		radius=4;
		
		area=pi*radius*radius;
		circumference=2*pi*radius;
		
	}
	public static void main(String[] args) {
		circleClass obj=new circleClass();
		
		obj.setValues();
		
		System.out.println("Area=" +obj.area);
		System.out.println("Circumference=" +obj.circumference);
		
	}
	

}
