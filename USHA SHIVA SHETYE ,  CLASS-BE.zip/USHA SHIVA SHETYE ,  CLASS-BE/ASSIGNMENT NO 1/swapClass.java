package Demo;

public class swapClass {
	int x,y,z;
	
	void setValues() {
		x=10;
		y=20;
		z=x;
		x=y;
		y=z;
		
	}
	
	public static void main(String[] args) {
		swapClass obj=new swapClass();
		
		System.out.println("value of x=" +obj.x);
		System.out.println("value of y=" +obj.y);
		
		obj.setValues();
		System.out.println("value of x=" +obj.x);
		System.out.println("value of y=" +obj.y);
		
	}
}
