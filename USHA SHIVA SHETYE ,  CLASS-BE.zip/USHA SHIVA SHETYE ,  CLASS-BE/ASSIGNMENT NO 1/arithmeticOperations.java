package Demo;

import java.math.*;

public class arithmeticOperations {
	
	int a,b,result,res1,res2;
	float res3;
	void setValues() {
		 a=45;
		 b=20;
		 result=a+b;
		 res1=a-b;
		 res2=a*b;
		 res3=a/b;

		
	}
	
		public static void main(String[] args) {

      arithmeticOperations obj=new arithmeticOperations();
  	
		obj.setValues();
		System.out.println("addition=" +obj.result);
		System.out.println("subtraction=" +obj.res1);
		System.out.println("multiplication=" +obj.res2);
		System.out.println("division=" +obj.res3);
		
		
	}
	
	

}
