import React from "react";
import '../styling/style.css'
function Imageslide(){
    let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].ClassName = dots[i].ClassName.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].ClassName += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
    return(
        <div>
        <div ClassName="slideshow-container">

            <div ClassName="mySlides fade">
            <div ClassName="numbertext">1 / 3</div>
            <img src="img_nature_wide.jpg" style="width:100%"/>
            <div ClassName="text">Caption Text</div>
            </div>

            <div ClassName="mySlides fade">
            <div ClassName="numbertext">2 / 3</div>
            <img src="img_snow_wide.jpg" style="width:100%"/>
            <div ClassName="text">Caption Two</div>
            </div>

            <div ClassName="mySlides fade">
            <div ClassName="numbertext">3 / 3</div>
            <img src="img_mountains_wide.jpg" style="width:100%"/>
            <div ClassName="text">Caption Three</div>
            </div>

        </div>
        <br/>

            <div style="text-align:center">
            <span ClassName="dot"></span> 
            <span ClassName="dot"></span> 
            <span ClassName="dot"></span> 
            </div>

        </div>
    )
}
export default Imageslide;