import React from "react";
import Header from '../Header'
import '../styling/style.css'
import Cart from "../cart/cart";
import '../cart/style.css'



function Home(){

    

    return(
        
        <div>

                <div className="row">
                    <Header/>

                </div>
                <div>
                    <Cart/>
                </div>

        </div>

    )
}

export default Home;