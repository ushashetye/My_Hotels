// import React from "react";
// import "../admin/register.css"
// function Register(){
    
    
    
//     return(
//         <div className="register-body">
//         <div className="register-main">
//             <h1>Register Form</h1>
//             { <p className="errP">*please fill every input field*</p>}
//             <br />
//             <p>Name</p>
//             <input type='text' ></input>
//             <br />
//             <p>Email</p>
//             <input type='text' ></input>
//             <br />
//             <p>Password</p>
//             <input type='password' ></input>
//             <br /><br />
//             <button >Register</button>
//         </div>
//         </div>
//     )

// }
// export default Register;