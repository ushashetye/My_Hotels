import React from "react";
import '../cart/style.css'
// import burger from '../cart/burger.jpg'
function Cart(){

    return(
        

            <div className="row">

                <div className="col-lg-9 " style={{paddingTop:'95px', display:'inline-flex',flexWrap:'wrap'}}>
                    <div className="row" style={{paddingLeft:'40px'}}>
                    <h2>
                        Inadian Food
                    </h2>



                    <div className="cbox">
                    {/* <img src="burger.jpg" alt="burger" style={{height:'100px',width:'100px'}} /> */}
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>
                        <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>
                        </div>
                    </div>

                    <div className="cbox">
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>
                        <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>
                    
                    <div className="cbox">
                        Name-burger
                        <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>
                    <div className="cbox">
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>                        
                    <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>

                    <div className="cbox">
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>                        
                    <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>

                    <div className="cbox">
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>                        
                    <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>

                    <div className="cbox">
                       <span>
                        Name-burger
                       </span>
                        <div className="cartb">
                        <input type='button' className='btn btn-success' href='home' value={'Price-100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>

                    <div className="cbox">
                    <div>
                        <h5 style={{color:'whitesmoke'}}>
                        Burger

                        </h5>
                    </div>                       
                     <div className="cartb">
                        <input id="burger" onClick="addToList(this)" type='button' className='btn btn-success' href='home' value={'100/-'} style={{width:'90px',textSizeAdjust:'15px',textAlign:'center',paddingLeft:'2px'}}></input>

                        </div>
                    </div>
                </div>

                   
                    
                    

                </div>

                <div className="col-lg-3">
                <div className="cs" >

                    <h4 style={{color:'white',textAlign:'center'}}>
                    Order Details

                    </h4>
                    <table id="orders">
                        <thead>
                            <tr style={{color:'white'}} >
                                <th>Sr.</th>
                                <th>Product</th>
                                <th>Qty</th>
                                <th>Price</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                
                            </tr>
                        </tbody>
                    </table>
                </div>

                </div>

                       

            </div>


    )
}


export default Cart;


