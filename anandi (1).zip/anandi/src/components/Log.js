import React from'react'
import '../components/styling/style.css';
 function Log()
{
    return(
        <div className='container'>

        
        <div className='lp'>

            <div className='lbox'>
                <div className='row'>
                    <div className='col-lg-12' style={{paddingTop:'100px',paddingLeft:'470px'}}>

                        <div className='box'>
                        <h1 style={{paddingTop:'20px'}}>
                        Login
                        </h1>
                        <div className='row' style={{paddingTop:'20px'}}>
                            <input type='text' className='btn' placeholder='Username' style={{borderColor:'transparent'}}></input>

                        </div>
                        <div className='row' style={{paddingTop:'20px'}}>
                            <input type='password' className='btn' placeholder='Password' style={{borderColor:'transparent'}}></input>

                        </div>
                        <div className='row' style={{paddingTop:'20px'}}>
                            <input type='button' className='btn1' href='home' value={'Login'}></input>

                        </div>
                        
                        <div className='row' style={{padding:'10px'}}>
                            

                            
                            <a href='reg'>

                            Don't have an account?

                            </a>

                        </div>

                        </div>

                        
                    </div>

                </div>
                
                
            </div>
        


         </div>

         </div>

    )
   
}
export default Log;