import React from "react";

function Reg()
{
    return(

         <div className='container'>

        
            <div className='lp'>

                <div className='lbox'>
                    <div className='row'>
                        <div className='col-lg-12' style={{paddingTop:'70px',paddingLeft:'470px'}}>

                            <div className='boxR'>
                            <h1 style={{paddingTop:'20px'}}>
                            Registration
                            </h1>
                            <div className='row' style={{paddingTop:'2px',textAlign:'left',paddingLeft:'70px'}}>
                                <h4>Enter Your Name :</h4>
                                <input type='text' className='btn' placeholder='Name' style={{borderColor:'transparent'}}></input>

                            </div>
                            <div className='row' style={{paddingTop:'5px',textAlign:'left',paddingLeft:'70px'}}>
                            <h4>Enter Your Mail Id :</h4>

                                <input type='password' className='btn' placeholder='E-mail' style={{borderColor:'transparent'}}></input>

                            </div>

                            <div className='row' style={{paddingTop:'20px'}}>
                                <input type='button' className='btn1' value={'Register'}></input>

                            </div>
                            
                            <div className='row' style={{padding:'15px'}}>
                                <a href='log'>
                                Login Here.


                                </a>

                            </div>

                            </div>

                            
                        </div>

                    </div>
                    
                    
                </div>



            </div>

            </div>
        
    )
}

export default Reg;