import './App.css';
import Log from './components/Log';
import Reg from './components/Reg';
import Home from './components/home/Home'
// import { BrowserRouter,Route, Routes } from "react-router-dom";

function App() {


  return (

    <div>
      {/* <BrowserRouter>
         <Routes>
           <Route path="/log" element={<Log/>} />
           <Route path='/home' element={<Home/>}/>
           <Route path="/reg" element={<Reg/>} />
           <Route path="*" element={<h1>Page not Found</h1>} />
          
           </Routes>
      </BrowserRouter> */}
      
     </div>
    
  );
}

export default App;




